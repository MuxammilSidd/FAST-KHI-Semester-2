#include <iostream>
using namespace std;

class Process {
   private:
      int pid;
      string name;
      int priority;
      int memory;

   public:
      // Default constructor
      Process() {
         pid = 0;
         name = "";
         priority = 0;
         memory = 0;
      }

      // Parameterized constructor
      Process(int p, string n, int pri, int mem) {
         pid = p;
         name = n;
         priority = pri;
         memory = mem;
      }

      // Member function to display process details
      void displayDetails() {
         cout << "Process ID: " << pid << endl;
         cout << "Process Name: " << name << endl;
         cout << "Process Priority: " << priority << endl;
         cout << "Process Memory: " << memory << " MB" << endl;
      }
};

class Scheduler {
   private:
      int maxProcesses;
      int numProcesses;
      Process *processes;

   public:
      // Default constructor
      Scheduler() {
         maxProcesses = 10;
         numProcesses = 0;
         processes = new Process[maxProcesses];
      }

      // Parameterized constructor
      Scheduler(int max) {
         maxProcesses = max;
         numProcesses = 0;
         processes = new Process[maxProcesses];
      }

      // Member function to add process
      void addProcess(int p, string n, int pri, int mem) {
         if (numProcesses < maxProcesses) {
            processes[numProcesses] = Process(p, n, pri, mem);
            numProcesses++;
            cout << "Process added successfully!" << endl;
         } else {
            cout << "Process limit reached!" << endl;
         }
      }

      // Member function to display all processes
      void displayProcesses() {
         if (numProcesses > 0) {
            for (int i = 0; i < numProcesses; i++) {
               cout << "Process " << i+1 << ":" << endl;
               processes[i].displayDetails();
               cout << endl;
            }
         } else {
            cout << "No processes to display!" << endl;
         }
      }

      // Destructor
      ~Scheduler() {
         delete[] processes;
      }
};

int main() {
   // Create a scheduler with default maxProcesses limit
   Scheduler s1;
   cout << "Scheduler 1 created successfully!" << endl;

   // Add some processes to the scheduler
   s1.addProcess(101, "Chrome", 3, 300);
   s1.addProcess(102, "VS Code", 2, 150);
   s1.addProcess(103, "Spotify", 4, 200);

   // Display all processes in the scheduler
   cout << "All processes in Scheduler 1:" << endl;
   s1.displayProcesses();

   // Create a scheduler with a custom maxProcesses limit
   Scheduler s2(5);
   cout << "Scheduler 2 created successfully!" << endl;

   // Add some processes to the scheduler
   s2.addProcess(201, "Firefox", 3, 250);
   s2.addProcess(202, "Discord", 2, 100);
   s2.addProcess(203, "Zoom", 4, 350);
   s2.addProcess(204, "Photoshop", 5, 500);
   s2.addProcess(205, "Sublime", 1, 100);

   // Display all processes in the scheduler
   cout << "All processes in Scheduler 2:" << endl;
   s2.displayProcesses();

   return 0;
}

