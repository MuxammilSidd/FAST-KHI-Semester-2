#include <iostream>
#include <string>

class Product {
private:
std::string name;
double price;
int quantity;

public:
Product(std::string name_, double price_, int quantity_)
: name(name_), price(price_), quantity(quantity_)
{
}

void updateQuantity(int quantity_) {
    quantity += quantity_;
}

std::string getName() const {
    return name;
}

double getPrice() const {
    return price;
}

int getQuantity() const {
    return quantity;
}
};

void printInventory(Product products[], int size) {
std::cout << "Inventory:\n";
for (int i = 0; i < size; i++) {
std::cout << "Name: " << products[i].getName() << "\n"
<< "Price: " << products[i].getPrice() << "\n"
<< "Quantity: " << products[i].getQuantity() << "\n\n";
}
}

int main() {
const int size = 3;
Product products[size] = {
Product("Shirt", 19.99, 10),
Product("TV", 299.99, 5),
Product("Bread", 2.99, 20)
};
printInventory(products, size);

return 0;
}

