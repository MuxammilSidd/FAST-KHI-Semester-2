#include <iostream>
#include <string>

using namespace std;

class Vehicle {
public:
	string type;
	float speed;
	float location;

	Vehicle(string type, float speed, float location) {
    	this->type = type;
    	this->speed = speed;
    	this->location = location;
	}

	void update_location(float time_elapsed) {
    	location += speed * time_elapsed;
	}
};

class Road {
public:
	float length;
	float speed_limit;
	float traffic_level;
	Vehicle* vehicles[10];
	int num_vehicles;

	Road() {
    	num_vehicles = 0;
	}

	void add_vehicle(Vehicle* vehicle) {
    	if (num_vehicles < 10) {
        	vehicles[num_vehicles] = vehicle;
        	num_vehicles++;
    	}
    	else {
        	cout << "Cannot add vehicle, road is full" << endl;
    	}
	}

	void remove_vehicle(Vehicle* vehicle) {
    	int index = -1;
    	for (int i = 0; i < num_vehicles; i++) {
        	if (vehicles[i] == vehicle) {
            	index = i;
            	break;
        	}
    	}
    	if (index != -1) {
        	for (int i = index; i < num_vehicles - 1; i++) {
            	vehicles[i] = vehicles[i+1];
        	}
        	num_vehicles--;
    	}
	}

	float travel_time(Vehicle* vehicle) {
    	float travel_time = length / vehicle->speed;
    	return travel_time;
	}
};

int main() {
	Vehicle car("Car", 60, 0);
	Vehicle truck("Truck", 40, 0);

	Road highway;
	highway.length = 100;
	highway.speed_limit = 70;
	highway.traffic_level = 0.5;
	highway.add_vehicle(&car);
	highway.add_vehicle(&truck);

	float time_elapsed = 1;
	car.update_location(time_elapsed);
	truck.update_location(time_elapsed);

	cout << "Car location: " << car.location << endl;
	cout << "Truck location: " << truck.location << endl;

	float car_travel_time = highway.travel_time(&car);
	float truck_travel_time = highway.travel_time(&truck);
	cout << "Car travel time on highway: " << car_travel_time << endl;
	cout << "Truck travel time on highway: " << truck_travel_time << endl;

	return 0;
}

