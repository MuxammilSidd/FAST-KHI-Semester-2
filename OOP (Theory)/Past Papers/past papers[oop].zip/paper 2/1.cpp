#include <iostream>

using namespace std;

class CoffeeShop {
private:
    static int coffeeBeans;
    static int milk;
    static int beveragesSold;

public:
    static void sellBeverage(int beansUsed, int milkUsed) {
        if (coffeeBeans >= beansUsed && milk >= milkUsed) {
            coffeeBeans -= beansUsed;
            milk -= milkUsed;
            beveragesSold++;
            cout << "Enjoy your beverage!" << endl;
        } else {
            cout << "Sorry, we are out of stock." << endl;
        }
    }

    static void displayInventory() {
        cout << "Current inventory:" << endl;
        cout << "Coffee beans: " << coffeeBeans << " grams" << endl;
        cout << "Milk: " << milk << " ml" << endl;
        cout << "Beverages sold: " << beveragesSold << endl;
    }
};

int CoffeeShop::coffeeBeans = 1000;
int CoffeeShop::milk = 1000;
int CoffeeShop::beveragesSold = 0;

int main() {
    int choice;
    while (true) {
        cout << "Please select a beverage to purchase:" << endl;
        cout << "1. Latte (requires 20g coffee beans and 150ml milk)" << endl;
        cout << "2. Cappuccino (requires 15g coffee beans and 100ml milk)" << endl;
        cout << "3. Espresso (requires 10g coffee beans and 50ml milk)" << endl;
        cout << "4. Exit" << endl;
        cin >> choice;

        switch (choice) {
            case 1:
                CoffeeShop::sellBeverage(20, 150);
                break;
            case 2:
                CoffeeShop::sellBeverage(15, 100);
                break;
            case 3:
                CoffeeShop::sellBeverage(10, 50);
                break;
            case 4:
                CoffeeShop::displayInventory();
                return 0;
            default:
                cout << "Invalid choice." << endl;
        }

        CoffeeShop::displayInventory();
    }

    return 0;
}

