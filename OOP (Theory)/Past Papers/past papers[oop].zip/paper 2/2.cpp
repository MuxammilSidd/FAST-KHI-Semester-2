#include <iostream>
#include <string>

using namespace std;

class Car {
    string make;
    string model;
    int year;
    int passengers;
    float rentalPrice;
    bool available;
    public:
        Car() {}
        Car(string make, string model, int year, int passengers, float rentalPrice) {
            this->make = make;
            this->model = model;
            this->year = year;
            this->passengers = passengers;
            this->rentalPrice = rentalPrice;
            this->available = true;
        }
        void setMake(string make) {
            this->make = make;
        }
        void setModel(string model) {
            this->model = model;
        }
        void setYear(int year) {
            this->year = year;
        }
        void setPassengers(int passengers) {
            this->passengers = passengers;
        }
        void setRentalPrice(float rentalPrice) {
            this->rentalPrice = rentalPrice;
        }
        void setAvailable(bool available) {
            this->available = available;
        }
        string getMake() {
            return make;
        }
        string getModel() {
            return model;
        }
        int getYear() {
            return year;
        }
        int getPassengers() {
            return passengers;
        }
        float getRentalPrice() {
            return rentalPrice;
        }
        bool isAvailable() {
            return available;
        }
};

class Payment {
    string creditCardNumber;
    string expirationDate;
    float amount;
public:
    Payment() {}
    Payment(string creditCardNumber, string expirationDate, float amount) {
        this->creditCardNumber = creditCardNumber;
        this->expirationDate = expirationDate;
        this->amount = amount;
    }
    void setCreditCardNumber(string creditCardNumber) {
        this->creditCardNumber = creditCardNumber;
    }
    void setExpirationDate(string expirationDate) {
        this->expirationDate = expirationDate;
    }
    void setAmount(int amount) {
        this->amount = amount;
    }
    string getCreditCardNumber() {
        return creditCardNumber;
    }
    string getExpirationDate() {
        return expirationDate;
    }
    float getAmount() {
        return amount;
    }
};

class Customer {
    string name;
    string address;
    string phone;
    string email;
    Payment* payment;
    public:
        Customer() {
        	//var =new object name ()
            payment = new  Payment();
        }
        Customer(string name, string address, string phone, string email) {
            this->name = name;
            this->address = address;
            this->phone = phone;
            this->email = email;
            payment = new Payment();
        }
        void setName(string name) {
            this->name = name;
        }
        void setAddress(string address) {
            this->address = address;
        }
        void setPhone(string phone) {
            this->phone = phone;
        }
        void setEmail(string email) {
            this->email = email;
        }
        string getName() {
            return name;
        }
        string getAddress() {
            return address;
        }
        string getPhone() {
            return phone;
        }
        string getEmail() {
            return email;
        }
        Payment* getPayment() {
            return payment;
        }

        void searchAvailableCars(Car cars[5]) {
            for (int i = 0; i < 5; i++) {
                if (cars[i].isAvailable()) {
                    cout << cars[i].getMake() << " " << cars[i].getModel() << " - " << cars[i].getRentalPrice() << " per day" << endl;
                }
            }
        }

        void reserveCar(Car& car) {
            car.setAvailable(false);
            cout << "Car has been reserved" << endl;
        }

        void viewRentalHistory(Car cars[5]) {
            for (int i = 0; i < 5; i++) {
                if (!cars[i].isAvailable()) 
                    cout << cars[i].getMake() << " " << cars[i].getModel() << " is already rented out." << endl;
                else 
                    cout << cars[i].getMake() << " " << cars[i].getModel() << " is available for rental." << endl;
            }
        }
        void makePayment(Payment *p) {
            payment = p;
            cout << "The payment has been made." << endl;
        }
        ~Customer() {
            delete payment;
        }
};
int main() {
    //1
    Car cArr[5] = { Car("Make1", "Model1", 1999, 4, 20000), 
                    Car("Make2", "Model2", 1998, 4, 20000), 
                    Car("Make3", "Model3", 1997, 4, 20000), 
                    Car("Make4", "Model4", 1996, 4, 20000), 
                    Car("Make5", "Model5", 1995, 4, 20000)};
    
    //2
    Customer cust;
    cust.setName("Umer Yousuf");
    cust.setAddress("CS Block");
    cust.setEmail("abeeha.sattar@nu.edu.pk");
    cust.setPhone("0331-3695834");

    //3
    cust.searchAvailableCars(cArr);
    
    //4
    cust.reserveCar(cArr[2]);
    cust.viewRentalHistory(cArr);

    //5
    Payment *p = new Payment("creditcardnumber", "9/9/2099", 20000);
    cust.makePayment(p);
    return 0;
}

