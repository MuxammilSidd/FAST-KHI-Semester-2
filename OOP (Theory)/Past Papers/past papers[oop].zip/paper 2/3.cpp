#include <iostream>
#include <string>

using namespace std;

// Base class for common attributes of Attendee and Organizer
class Person {
protected:
    string name;
    string email;
    string contactNumber;

public:
    Person(string name, string email, string contactNumber)
        : name(name), email(email), contactNumber(contactNumber) {}

    string getName() const { return name; }
    string getEmail() const { return email; }
    string getContactNumber() const { return contactNumber; }
};

// Derived class for Attendee
class Attendee : public Person {
public:
    Attendee(string name, string email, string contactNumber)
        : Person(name, email, contactNumber) {}
};

// Derived class for Organizer
class Organizer : public Person {
public:
    Organizer(string name, string email, string contactNumber)
        : Person(name, email, contactNumber) {}
};

// Base class for common attributes of Venue
class EventEntity {
protected:
    string name;
    int capacity;
    bool available;

public:
    EventEntity(string name, int capacity)
        : name(name), capacity(capacity), available(true) {}

    string getName() const { return name; }
    int getCapacity() const { return capacity; }
    bool isAvailable() const { return available; }
    void setAvailable(bool available) { this->available = available; }
};

// Derived class for Venue
class Venue : public EventEntity {
public:
    Venue(string name, int capacity)
        : EventEntity(name, capacity) {}
};

// Main class for Procom managing Attendees, Organizers, and Venues
class Procom {
private:
    Attendee* attendees[100];
    int numAttendees;
    Organizer* organizers[10];
    int numOrganizers;
    Venue* venues[10];
    int numVenues;

public:
    Procom() : numAttendees(0), numOrganizers(0), numVenues(0) {}

    void addAttendee(string name, string email, string contactNumber) {
        attendees[numAttendees++] = new Attendee(name, email, contactNumber);
    }

    void removeAttendee(int index) {
        delete attendees[index];
        for (int i = index; i < numAttendees ; i++) {
            attendees[i] = attendees[i + 1];
        }
        numAttendees--;
    }

    void addOrganizer(string name, string email, string contactNumber) {
        organizers[numOrganizers++] = new Organizer(name, email, contactNumber);
    }

    void removeOrganizer(int index) {
        delete organizers[index];
        for (int i = index; i < numOrganizers - 1; i++) {
            organizers[i] = organizers[i + 1];
        }
        numOrganizers--;
    }

    void addVenue(string name, int capacity) {
        venues[numVenues++] = new Venue(name, capacity);
    }

    void viewAttendees() const {
        for (int i = 0; i < numAttendees; i++) {
            cout << attendees[i]->getName() << " " << attendees[i]->getEmail() << " " << attendees[i]->getContactNumber();
        }
    }

    void viewOrganizers() const {
        for (int i = 0; i < numOrganizers; i++) {
            cout << organizers[i]->getName() << " " << organizers[i]->getEmail() << " " << organizers[i]->getContactNumber();
        }
    }

    void viewVenues() const {
        for (int i = 0; i < numVenues; i++) {
            cout << venues[i]->getName();
        }
    }

    ~Procom() {
        for (int i = 0; i < numAttendees; i++) {
            delete attendees[i];
        }
        for (int i = 0; i < numOrganizers; i++) {
            delete organizers[i];
        }
        for (int i = 0; i < numVenues; i++) {
            delete venues[i];
        }
    }
};

int main() {
    // Create an instance of the Procom class
    Procom procom;

    // Add attendees
    procom.addAttendee("John Doe", "john@example.com", "123-456-7890");
    procom.addAttendee("Jane Smith", "jane@example.com", "987-654-3210");

    // Add organizers
    procom.addOrganizer("Organizer 1", "org1@example.com", "111-222-3333");
    procom.addOrganizer("Organizer 2", "org2@example.com", "444-555-6666");

    // Add venues
    procom.addVenue("Conference Hall A", 200);
    procom.addVenue("Meeting Room B", 50);

    // View attendees
    cout << "Attendees:\n";
    procom.viewAttendees();
    cout << "\n\n";

    // View organizers
    cout << "Organizers:\n";
    procom.viewOrganizers();
    cout << "\n\n";

    // View venues
    cout << "Venues:\n";
    procom.viewVenues();
    cout << "\n\n";

    // Remove an attendee (just for demonstration)
    procom.removeAttendee(0);

    // View attendees after removal
    cout << "Attendees after removal:\n";
    procom.viewAttendees();
    cout << "\n\n";

    return 0;
}

